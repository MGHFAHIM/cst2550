#ifndef BOOK_H
#define BOOK_H

#include <string>

class Book {
private:
    int id;
    std::string name;
    std::string authorFirstName;
    std::string authorLastName;
    std::string type;
    int pageCount;

public:
    // Constructor
    Book(int id, const std::string& name, const std::string& authorFirstName,
         const std::string& authorLastName, const std::string& type, int pageCount);

    // Getter methods
    int getId() const;
    std::string getName() const;
    std::string getAuthorFirstName() const;
    std::string getAuthorLastName() const;
    std::string getType() const;
    int getPageCount() const;

    // Overloaded equality operator for book comparison
    bool operator==(const Book& other) const;
};

#endif // BOOK_H

