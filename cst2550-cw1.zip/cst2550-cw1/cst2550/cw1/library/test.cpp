#define CATCH_CONFIG_MAIN
#include "catch.hpp"
#include "Library.h"
#include "Member.h"
#include "Book.h"

TEST_CASE("Library functionality", "[library]") {
    Library library;

    SECTION("Add a member") {
        Member member("John Doe");
        REQUIRE(library.addMember(member) == true);
    }

    SECTION("Issue a book to a member") {
        Member member("Jane Doe");
        Book book(1, "Sample Book", "Author", "Science fiction", 200);
        REQUIRE(library.issueBookToMember(book, member) == true);
    }

    SECTION("Return a book from a member") {
        Member member("Alice Smith");
        Book book(2, "Another Book", "Author2", "Mystery", 150);

        library.issueBookToMember(book, member);
        REQUIRE(library.returnBookFromMember(book, member) == true);
    }



    SECTION("Additional checks") {
        // Perform additional checks or cleanup
        // ...
    }
}

TEST_CASE("Member functionality", "[member]") {
    SECTION("Check for overdue books") {
        Member member("Bob Johnson");
        Book overdueBook(3, "Overdue Book", "Author3", "Thriller", 180);
        overdueBook.setDueDate(ChronoTime::now() - ChronoTime::days(4)); // Set due date 4 days ago

        member.borrowBook(overdueBook);

        REQUIRE(member.hasOverdueBooks() == true);
    }

    SECTION("Calculate fine for overdue books") {
        Member member("Charlie Brown");
        Book overdueBook(4, "Late Return Book", "Author4", "Fantasy", 220);
        overdueBook.setDueDate(ChronoTime::now() - ChronoTime::days(2)); // Set due date 2 days ago

        member.borrowBook(overdueBook);


        double expectedFine = 2.0; // 2 days overdue

        REQUIRE(member.calculateFine() == expectedFine);
    }
}

TEST_CASE("Book functionality", "[book]") {
    SECTION("Set and get book details") {
        Book book(1, "Test Book", "Test Author", "Test Genre", 150);

        REQUIRE(book.getId() == 1);
        REQUIRE(book.getTitle() == "Test Book");
        REQUIRE(book.getAuthor() == "Test Author");
        REQUIRE(book.getGenre() == "Test Genre");
        REQUIRE(book.getPageCount() == 150);
    }

    SECTION("Set and get due date") {
        Book book(2, "Another Book", "Author2", "Genre2", 200);

        ChronoTime dueDate = ChronoTime::now() + ChronoTime::days(7); // Due in 7 days
        book.setDueDate(dueDate);

        REQUIRE(book.getDueDate() == dueDate);
    }

    SECTION("Check if book is overdue") {
        Book overdueBook(3, "Overdue Book", "Author3", "Genre3", 180);

        ChronoTime dueDate = ChronoTime::now() - ChronoTime::days(2); // Due 2 days ago
        overdueBook.setDueDate(dueDate);

        REQUIRE(overdueBook.isOverdue() == true);
    }


}

