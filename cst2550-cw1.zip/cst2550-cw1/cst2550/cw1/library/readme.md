# Library Management System

## Introduction

This project implements a basic Library Management System with functionality to add members, books, issue books to members, return books from members, display borrowed books, and calculate fines.

## Code Structure

### `Book.h` and `Book.cpp`

Defines the `Book` class with properties such as ID, name, author details, type, and page count. It also includes an overloaded equality operator for book comparison.

### `Member.h` and `Member.cpp`

Defines the `Member` class representing library members. It includes properties such as ID, first name, last name, and a vector of borrowed books. Member functions handle borrowing and returning books, checking for overdue books, and calculating fines.

### `Library.h` and `Library.cpp`

Implements the `Library` class with vectors for storing members and available books. Member functions include adding members and books, issuing and returning books, and helper functions to find members and books by ID.

### `main.cpp`

Contains the main function, which initializes the library and demonstrates its functionality.

### `catch.hpp`

The Catch2 testing framework header file for unit testing.

## Testing

Unit tests are implemented using Catch2. The tests cover library functionality, member behavior, and book-related operations.

To run the tests, compile the project and execute the generated executable.

## Usage

1. Initialize the Library.
2. Add members and books to the library.
3. Issue and return books for library members.
4. Display borrowed books for a specific member.
5. Calculate fines for overdue books.

## Dependencies

- Catch2 (Included in the project as `catch.hpp`)

## Building the Project

Compile the source files using your preferred C++ compiler. Make sure to include `catch.hpp` for testing.

```bash
g++ main.cpp Book.cpp Member.cpp Library.cpp -o LibrarySystem
