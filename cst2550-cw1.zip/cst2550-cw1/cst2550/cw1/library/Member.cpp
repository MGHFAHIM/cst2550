#include "Member.h"
#include <algorithm>

// Constructor
Member::Member(int memberId, const std::string& firstName, const std::string& lastName)
    : memberId(memberId), firstName(firstName), lastName(lastName) {}

// Getter methods
int Member::getMemberId() const {
    return memberId;
}

std::string Member::getFirstName() const {
    return firstName;
}

std::string Member::getLastName() const {
    return lastName;
}

std::vector<Book> Member::getBorrowedBooks() const {
    return borrowedBooks;
}

// Member functions
void Member::borrowBook(const Book& book) {
    borrowedBooks.push_back(book);
}

void Member::returnBook(const Book& book) {
    // Remove the returned book from the borrowedBooks vector
    borrowedBooks.erase(std::remove(borrowedBooks.begin(), borrowedBooks.end(), book), borrowedBooks.end());
}


