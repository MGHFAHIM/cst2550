#include "Library.h"
#include <iostream>

// Constructor
Library::Library() {}

// Member functions
void Library::addMember(const Member& member) {
    members.push_back(member);
}

void Library::addBook(const Book& book) {
    availableBooks.push_back(book);
}

void Library::issueBook(int memberId, int bookId) {
    // Find the member and book
    Member* member = findMemberById(memberId);
    Book* book = findBookById(bookId);

    // Check if both member and book exist
    if (member && book) {
        // Check if the book is available
        if (book->isAvailable()) {
            // Borrow the book
            member->borrowBook(*book);
            book->setBorrowed(true);

            std::cout << "Book issued successfully." << std::endl;
        } else {
            std::cout << "Book is not available for borrowing." << std::endl;
        }
    } else {
        std::cout << "Member or book not found." << std::endl;
    }
}

void Library::returnBook(int memberId, int bookId) {
    // Find the member and book
    Member* member = findMemberById(memberId);
    Book* book = findBookById(bookId);

    // Check if both member and book exist
    if (member && book) {
        // Return the book
        member->returnBook(*book);
        book->setBorrowed(false);

        std::cout << "Book returned successfully." << std::endl;
    } else {
        std::cout << "Member or book not found." << std::endl;
    }
}


// Helper functions
Member* Library::findMemberById(int memberId) {
    auto it = std::find_if(members.begin(), members.end(), [memberId](const Member& member) {
        return member.getId() == memberId;
    });

    if (it != members.end()) {
        return &(*it); // Return a pointer to the found member
    } else {
        return nullptr; // Member not found
    }
}

Book* Library::findBookById(int bookId) {
    auto it = std::find_if(availableBooks.begin(), availableBooks.end(), [bookId](const Book& book) {
        return book.getId() == bookId;
    });

    if (it != availableBooks.end()) {
        return &(*it); // Return a pointer to the found book
    } else {
        return nullptr; // Book not found
    }
}

