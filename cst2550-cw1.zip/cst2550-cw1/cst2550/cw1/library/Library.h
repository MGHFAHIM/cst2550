#ifndef LIBRARY_H
#define LIBRARY_H

#include <vector>
#include "Member.h"
#include "Book.h"

class Library {
private:
    std::vector<Member> members;
    std::vector<Book> availableBooks;

public:
    // Constructor
    Library();

    // Member functions
    void addMember(const Member& member);
    void addBook(const Book& book);
    void issueBook(int memberId, int bookId);
    void returnBook(int memberId, int bookId);
    void displayBorrowedBooks(int memberId) const;
    void calculateFine(int memberId);

private:
    // Helper functions
    Member* findMemberById(int memberId);
    Book* findBookById(int bookId);
};

#endif // LIBRARY_H

