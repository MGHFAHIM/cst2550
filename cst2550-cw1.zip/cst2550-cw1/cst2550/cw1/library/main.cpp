#include <algorithm> // Add this line to include the <algorithm> header
#include <iostream>
#include <vector>
#include <chrono>


class Book {
public:
    int id;
    std::string name;
    std::string authorFirstName;
    std::string authorLastName;
    std::string type;
    int pageCount;

    Book(int _id, std::string _name, std::string _authorFirstName, std::string _authorLastName, std::string _type, int _pageCount)
        : id(_id), name(_name), authorFirstName(_authorFirstName), authorLastName(_authorLastName), type(_type), pageCount(_pageCount) {}
};

class BorrowedBook {
public:
    Book* book;
    std::chrono::system_clock::time_point issueDate;

    BorrowedBook(Book* _book, const std::chrono::system_clock::time_point& _issueDate)
        : book(_book), issueDate(_issueDate) {}

    const std::chrono::system_clock::time_point& getIssueDate() const {
        return issueDate;
    }
};

class Member {
public:
    int id;
    std::string name;
    std::vector<BorrowedBook> borrowedBooks;

    Member(int _id, std::string _name) : id(_id), name(_name) {}

    bool hasOverdueBooks() const {
        auto currentDate = std::chrono::system_clock::now();

        for (const BorrowedBook& borrowedBook : borrowedBooks) {
            auto dueDate = borrowedBook.getIssueDate() + std::chrono::hours(3 * 24); // Assuming 3 days due period

            if (dueDate < currentDate) {
                return true; // At least one book is overdue
            }
        }

        return false; // No overdue books
    }

    double calculateFine() const {
        auto currentDate = std::chrono::system_clock::now();
        double fine = 0.0;

        for (const BorrowedBook& borrowedBook : borrowedBooks) {
            auto dueDate = borrowedBook.getIssueDate() + std::chrono::hours(3 * 24); // Assuming 3 days due period

            if (dueDate < currentDate) {
                // Calculate the number of days overdue
                auto overdueDays = std::chrono::duration_cast<std::chrono::hours>(currentDate - dueDate).count() / 24.0;

                // Assuming a fine rate of £1 per day overdue
                fine += overdueDays;
            }
        }

        return fine;
    }
};

class Library {
public:
    std::vector<Book> availableBooks;
    std::vector<Member> members;

    void addMember(const Member& member) {
        members.push_back(member);
        displayMemberDetails(member);
    }

    void issueBookToMember(Book& book, Member& member) {
        auto currentDate = std::chrono::system_clock::now();
        member.borrowedBooks.push_back(BorrowedBook(&book, currentDate));
    }

    void returnBookFromMember(Book& book, Member& member) {
        auto it = std::find_if(member.borrowedBooks.begin(), member.borrowedBooks.end(),
                               [&book](const BorrowedBook& borrowedBook) { return borrowedBook.book == &book; });

        if (it != member.borrowedBooks.end()) {
            member.borrowedBooks.erase(it);
        }
    }

    void displayAllBooksBorrowedByMember(const Member& member) {
        std::cout << "Books borrowed by Member " << member.id << " - " << member.name << ":\n";

        for (const BorrowedBook& borrowedBook : member.borrowedBooks) {
            std::cout << "Book ID: " << borrowedBook.book->id << ", Name: " << borrowedBook.book->name << "\n";
        }
    }

    void calculateFineForMember(const Member& member) {
        double fine = member.calculateFine();
        std::cout << "Fine for Member " << member.id << " - " << member.name << ": £" << fine << "\n";
    }

private:
    void displayMemberDetails(const Member& member) {
        std::cout << "New Member Added:\n";
        std::cout << "Member ID: " << member.id << ", Name: " << member.name << "\n";
    }
};

int main() {
    // Example Usage
    Library library;

    Book book1(1, "Book1", "Author1", "LastName1", "Type1", 200);
    Book book2(2, "Book2", "Author2", "LastName2", "Type2", 250);

    Member member1(101, "Member1");
    Member member2(102, "Member2");

    library.addMember(member1);
    library.addMember(member2);

    library.issueBookToMember(book1, member1);
    library.issueBookToMember(book2, member2);

    library.displayAllBooksBorrowedByMember(member1);
    library.displayAllBooksBorrowedByMember(member2);

    library.returnBookFromMember(book1, member1);
    library.returnBookFromMember(book2, member2);

    library.calculateFineForMember(member1);
    library.calculateFineForMember(member2);

    return 0;
}
