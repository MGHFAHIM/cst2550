#include "Book.h"

// Constructor
Book::Book(int id, const std::string& name, const std::string& authorFirstName,
           const std::string& authorLastName, const std::string& type, int pageCount)
    : id(id), name(name), authorFirstName(authorFirstName), authorLastName(authorLastName),
      type(type), pageCount(pageCount) {}

// Getter methods
int Book::getId() const {
    return id;
}

std::string Book::getName() const {
    return name;
}

std::string Book::getAuthorFirstName() const {
    return authorFirstName;
}

std::string Book::getAuthorLastName() const {
    return authorLastName;
}

std::string Book::getType() const {
    return type;
}

int Book::getPageCount() const {
    return pageCount;
}

// Overloaded equality operator for book comparison
bool Book::operator==(const Book& other) const {
    // Compare based on book ID
    return this->id == other.id;
}

