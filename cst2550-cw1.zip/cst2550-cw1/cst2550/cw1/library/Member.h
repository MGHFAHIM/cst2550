#ifndef MEMBER_H
#define MEMBER_H

#include <string>
#include <vector>
#include "Book.h"

class Member {
private:
    int memberId;
    std::string firstName;
    std::string lastName;
    std::vector<Book> borrowedBooks;

public:
    // Constructor
    Member(int memberId, const std::string& firstName, const std::string& lastName);

    // Getter methods
    int getMemberId() const;
    std::string getFirstName() const;
    std::string getLastName() const;
    std::vector<Book> getBorrowedBooks() const;

    // Member functions
    void borrowBook(const Book& book);
    void returnBook(const Book& book);
    bool hasOverdueBooks() const;
    double calculateFine() const;
};

#endif // MEMBER_H

